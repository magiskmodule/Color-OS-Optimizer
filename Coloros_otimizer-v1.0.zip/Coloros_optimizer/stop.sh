#!/bin/bash

# Display a notification about script completion
cmd notification post -S bigtext -t 'notification' 'Tag' '🚀 installing Color Os optimizer wait & enjoy!! 🎉' > /dev/null 2>&1
echo ""
echo ""

echo "░█████╗░░█████╗░██╗░░░░░░█████╗░██████╗░  ░█████╗░░██████╗"
echo "██╔══██╗██╔══██╗██║░░░░░██╔══██╗██╔══██╗  ██╔══██╗██╔════╝"
echo "██║░░╚═╝██║░░██║██║░░░░░██║░░██║██████╔╝  ██║░░██║╚█████╗░"
echo "██║░░██╗██║░░██║██║░░░░░██║░░██║██╔══██╗  ██║░░██║░╚═══██╗"
echo "╚█████╔╝╚█████╔╝███████╗╚█████╔╝██║░░██║  ╚█████╔╝██████╔╝"
echo "░╚════╝░░╚════╝░╚══════╝░╚════╝░╚═╝░░╚═╝  ░╚════╝░╚═════╝░"

# Display device information
echo ""
echo "🔍📱 Device Information"
echo "-----------------------"
echo "• Baseband Version  ➜ $(getprop gsm.version.baseband)"
sleep 0.1
echo "• Kernel            ➜ $(uname -r)"
sleep 0.1
echo "• Android SDK       ➜ $(getprop ro.build.version.sdk)"
sleep 0.1
echo "• Android Version   ➜ $(getprop ro.build.version.release)"
sleep 0.1
echo "• Device Model      ➜ $(getprop ro.product.model)"
sleep 0.1
echo "• Brand             ➜ $(getprop ro.product.brand)"
sleep 0.1
echo "• Model             ➜ $(getprop ro.product.model)"
sleep 0.1
echo "• Product           ➜ $(getprop ro.build.product)"
sleep 0.1
echo "• Hardware          ➜ $(getprop ro.hardware)"
sleep 0.1
echo "• GPU               ➜ $(getprop ro.opengles.version)"
sleep 0.1
echo "• CPU               ➜ $(getprop ro.product.cpu.abi)"
sleep 0.1
echo "• Build             ➜ $(getprop ro.build.description)"
sleep 0.1
echo ""
echo "⚠️ Important: do with you own risk!."
echo "⚠️ Use this info as a foundation for precise tweaks."
echo "⚠️ Verify compatibility before modifying for best results."


echo ""
echo "⚙️ Tweak Development ⚙️"
echo "---------------------"
echo "• Developers: @reljawa" 
echo ""
echo ""
echo "Uinstalling Color Os optimizer"
echo ""
sleep 1

# Function to set system properties
properties=(
"dev_perf skia_use_binary_exec"
"dev_perf hwui_shader_inverse3"
"dev_perf sem_enhanced_cpu_responsiveness"
"dev_perf push_rendering_constnant"
"dev_perf hwui_enable_queue"
"launcher ENABLE_SMARTSPACE_ENHANCED"
  )

success_count=0
failure_count=0

for command in "${properties[@]}"; do
    if cmd device_config delete $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Setting system properties..."
sleep 0.5

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Main script starts here

# Global settings

global_settings=(
"persist.qti.chips_tune"
"power_check_interval"
"power_check_max_cpu_0"
"power_check_max_cpu_1"
"power_check_max_cpu_2"
"power_check_max_cpu_3"
"power_check_max_cpu_4"
"power_check_max_cpu_5"
"power_check_max_cpu_6"
"power_check_max_cpu_7"
)

success_count=0
failure_count=0

for command in "${global_settings[@]}"; do
    if settings delete global $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply Global Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Secure settings

secure_settings=(
"coloros_screen_refresh_rate"
"device_thermal_refresh_rate_enabled"
"game_temperature_control"
"high_priority"
"oplus_games_incerase_frame_rate_switch_key"
"oppo_thermal_service"
)

success_count=0
failure_count=0

for command in "${secure_settings[@]}"; do
    if settings delete secure $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply Secure Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# System Table

system_settings=(
"com.coloros.gamespaceui.su"
"device_max_limit"
"recording_settings_frame_rate"
)

success_count=0
failure_count=0

for command in "${system_settings[@]}"; do
    if settings delete system $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply System Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Cmd command

cmd_setrings=(
"activity kill-all"
)

success_count=0
failure_count=0

for command in "${cmd_setrings[@]}"; do
    if cmd $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Please wait a moment..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

sleep 1
echo ""
echo "All tweaks successfully uinstalled [✓]"
echo ""
echo ""
echo "🚀 Color os Optimizer successfuly Uinstalled"
echo "🔥 Push Your Limits, Elevate Your Experience!"
echo "🙏 Thanks for choosing Tweak Development. Game on!"
echo ""
sleep 1

echo ""

echo "   __|  |  |  __|   __|  __|   __|    | "
echo " \__ \  |  | (     (     _|  \__ \   _| "
echo " ____/ \__/ \___| \___| ___| ____/   _) "
                                        
echo""
cmd notification post -S bigtext -t 'notification' 'Tag' '🚀 succes uinstallColor Os optimizer enjoy!! 🎉' > /dev/null 2>&1