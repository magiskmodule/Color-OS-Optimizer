#!/bin/bash

# Display a notification about script completion
cmd notification post -S bigtext -t 'notification' 'Tag' '🚀 installing Color Os optimizer wait & enjoy!! 🎉' > /dev/null 2>&1
echo ""
echo ""

echo "░█████╗░░█████╗░██╗░░░░░░█████╗░██████╗░  ░█████╗░░██████╗"
echo "██╔══██╗██╔══██╗██║░░░░░██╔══██╗██╔══██╗  ██╔══██╗██╔════╝"
echo "██║░░╚═╝██║░░██║██║░░░░░██║░░██║██████╔╝  ██║░░██║╚█████╗░"
echo "██║░░██╗██║░░██║██║░░░░░██║░░██║██╔══██╗  ██║░░██║░╚═══██╗"
echo "╚█████╔╝╚█████╔╝███████╗╚█████╔╝██║░░██║  ╚█████╔╝██████╔╝"
echo "░╚════╝░░╚════╝░╚══════╝░╚════╝░╚═╝░░╚═╝  ░╚════╝░╚═════╝░"

# Display device information
echo ""
echo "🔍📱 Device Information"
echo "-----------------------"
echo "• Baseband Version  ➜ $(getprop gsm.version.baseband)"
sleep 0.1
echo "• Kernel            ➜ $(uname -r)"
sleep 0.1
echo "• Android SDK       ➜ $(getprop ro.build.version.sdk)"
sleep 0.1
echo "• Android Version   ➜ $(getprop ro.build.version.release)"
sleep 0.1
echo "• Device Model      ➜ $(getprop ro.product.model)"
sleep 0.1
echo "• Brand             ➜ $(getprop ro.product.brand)"
sleep 0.1
echo "• Model             ➜ $(getprop ro.product.model)"
sleep 0.1
echo "• Product           ➜ $(getprop ro.build.product)"
sleep 0.1
echo "• Hardware          ➜ $(getprop ro.hardware)"
sleep 0.1
echo "• GPU               ➜ $(getprop ro.opengles.version)"
sleep 0.1
echo "• CPU               ➜ $(getprop ro.product.cpu.abi)"
sleep 0.1
echo "• Build             ➜ $(getprop ro.build.description)"
sleep 0.1
echo ""
echo "⚠️ Important: do with you own risk!."
echo "⚠️ Use this info as a foundation for precise tweaks."
echo "⚠️ Verify compatibility before modifying for best results."


echo ""
echo "⚙️ Tweak Development ⚙️"
echo "---------------------"
echo "• Developers: @reljawa" 
echo ""
echo "• Version 1.0"
echo ""
echo "Installing Color Os optimizer"
echo ""
sleep 1

# Function to set system properties
properties=(
"dev_perf skia_use_binary_exec true"
"dev_perf hwui_shader_inverse3 true"
"dev_perf sem_enhanced_cpu_responsiveness 1"
"dev_perf push_rendering_constnant 1"
"dev_perf hwui_enable_queue true"
"launcher ENABLE_SMARTSPACE_ENHANCED true"
  )

success_count=0
failure_count=0

for command in "${properties[@]}"; do
    if cmd device_config put $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Setting system properties..."
sleep 0.5

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Main script starts here

# Global settings

global_settings=(
"persist.qti.chips_tune 00xFF"
"power_check_interval 0"
"power_check_max_cpu_0 0"
"power_check_max_cpu_1 0"
"power_check_max_cpu_2 0"
"power_check_max_cpu_3 0"
"power_check_max_cpu_4 0"
"power_check_max_cpu_5 0"
"power_check_max_cpu_6 0"
"power_check_max_cpu_7 0"
)

success_count=0
failure_count=0

for command in "${global_settings[@]}"; do
    if settings put global $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply Global Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Secure settings

secure_settings=(
"coloros_screen_refresh_rate 3"
"device_thermal_refresh_rate_enabled 0"
"game_temperature_control 0"
"high_priority game"
"oplus_games_incerase_frame_rate_switch_key 1"
"oppo_thermal_service 0"
)

success_count=0
failure_count=0

for command in "${secure_settings[@]}"; do
    if settings put secure $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply Secure Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# System Table

system_settings=(
"com.coloros.gamespaceui.su 1"
"device_max_limit 0"
"recording_settings_frame_rate 90"
)

success_count=0
failure_count=0

for command in "${system_settings[@]}"; do
    if settings put system $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Apply System Settings..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

# Cmd command

cmd_setrings=(
"activity kill-all"
)

success_count=0
failure_count=0

for command in "${cmd_setrings[@]}"; do
    if cmd $command >/dev/null 2>&1; then
        success_count=$((success_count + 1))
    else
        failure_count=$((failure_count + 1))
        failed_commands+=("$command")
    fi
done

echo "Please wait a moment..."
sleep 1

echo "• Total commands apply successfully: $success_count"
echo "• Total commands failed to apply: $failure_count"
echo ""

sleep 1
echo ""
echo "All tweaks successfully installed [✓]"
echo ""
echo ""
echo "🚀 Color Os Optimizer successfuly Uinstalled"
echo "🔥 Push Your Limits, Elevate Your Experience!"
echo "🙏 Thanks for choosing Tweak Development. Game on!"
echo ""
sleep 1

echo ""

echo "   __|  |  |  __|   __|  __|   __|    | "
echo " \__ \  |  | (     (     _|  \__ \   _| "
echo " ____/ \__/ \___| \___| ___| ____/   _) "
                                        
echo""
cmd notification post -S bigtext -t 'notification' 'Tag' '🚀 succes installing Color Os optimizer enjoy!! 🎉' > /dev/null 2>&1