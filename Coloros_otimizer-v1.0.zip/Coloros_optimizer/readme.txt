Color Os Optimizer
dev @reljawa
version 1.0

install: sh /sdcard/Coloros_optimizer/run.sh

uinstall: sh /sdcard/Coloros_optimizer/stop.sh

feature:
-mengoptimalkan kinerja system
-boost fps
-meningkatkan kinerja untuk kebutuhan game
-mematikan device limit
-disable screensaver
-refresh rate level 
-disble power check for cpu